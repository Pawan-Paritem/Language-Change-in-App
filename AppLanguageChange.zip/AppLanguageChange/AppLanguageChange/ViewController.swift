//
//  ViewController.swift
//  AppLanguageChange
//
//  Created by APPLE on 03/07/2024.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lName: UILabel!
    @IBOutlet weak var fName: UILabel!
    
    @IBOutlet weak var segmant: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func segmentButtonAction(_ sender: UISegmentedControl) {
        if segmant.selectedSegmentIndex == 0 {
            fName.text = "FirstNameKey".localizableString(loc: "en")
            lName.text = "LastNameKey".localizableString(loc: "en")
        }  else {
            fName.text = "FirstNameKey".localizableString(loc: "de")
            lName.text = "LastNameKey".localizableString(loc: "de")
        }
    }
}


extension String {
    func localizableString(loc: String) -> String {
        let path = Bundle.main.path(forResource: loc, ofType: "lproj") ?? ""
        
        let bundle = Bundle(path: path)
        return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "" ,comment: "")
    }
}
